// Local-only Node server that runs the REAL business handler with a fake supabase,
// so the Vite proxy at /functions/v1/app can be exercised end-to-end without Deno.
import http from "node:http";
import { handleWaitlist } from "../functions/handler.mjs";

const rows = [];
const supabase = {
  from() {
    return {
      insert(rec) {
        if (rows.some((r) => r.email === rec.email)) {
          return Promise.resolve({ data: null, error: { code: "23505" } });
        }
        rows.push(rec);
        return Promise.resolve({ data: null, error: null });
      },
    };
  },
};

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const body = Buffer.concat(chunks);
  const request = new Request(url.toString(), {
    method: req.method,
    headers: req.headers,
    body: ["GET", "HEAD"].includes(req.method) ? undefined : body,
  });
  const response = await handleWaitlist({ request, supabase });
  res.statusCode = response.status;
  response.headers.forEach((v, k) => res.setHeader(k, v));
  res.end(await response.text());
});

server.listen(8000, "127.0.0.1", () => {
  console.log("Local waitlist Function on http://127.0.0.1:8000/functions/v1/app?action=ping");
});
