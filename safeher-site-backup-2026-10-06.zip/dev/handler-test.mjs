import { handleWaitlist } from "../functions/handler.mjs";

const rows = [];
const supabase = {
  from() {
    return {
      insert(rec) {
        if (rows.some((r) => r.email === rec.email)) {
          return Promise.resolve({ data: null, error: { code: "23505" } });
        }
        rows.push(rec);
        return Promise.resolve({ data: null, error: null });
      },
    };
  },
};

const call = (method, url, body) =>
  handleWaitlist({
    request: new Request(url, {
      method,
      headers: body ? { "content-type": "application/json" } : {},
      body: body ? JSON.stringify(body) : undefined,
    }),
    supabase,
  });

const base = "http://x/functions/v1/app";
const show = async (label, p) => {
  const r = await p;
  console.log(label, r.status, JSON.stringify(await r.json()));
};

await show("ping          ", call("GET", `${base}?action=ping`));
await show("valid join    ", call("POST", `${base}?action=join`, { name: "Asha Rao", email: "asha@ex.com", city: "Pune" }));
await show("dup email     ", call("POST", `${base}?action=join`, { name: "Asha Again", email: "ASHA@ex.com ", city: "" }));
await show("bad email     ", call("POST", `${base}?action=join`, { name: "Bob", email: "nope" }));
await show("missing name  ", call("POST", `${base}?action=join`, { name: "  ", email: "b@ex.com" }));
await show("wrong method  ", call("GET", `${base}?action=join`));
await show("unknown action", call("GET", `${base}?action=nope`));
await show("non-json body ", handleWaitlist({ request: new Request(`${base}?action=join`, { method: "POST", headers: { "content-type": "text/plain" }, body: "hi" }), supabase }));
console.log("stored rows:", rows.length);
