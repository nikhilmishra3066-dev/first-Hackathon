// SafeHer waitlist Function. Public signup form: anonymous INSERT only.
// No SELECT is granted, so visitor emails/cities are never publicly readable.
const json = (body, status = 200, headers = {}) =>
  Response.json(body, { status, headers: { "cache-control": "no-store", ...headers } });

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function readText(value, max) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim().replace(/\s+/g, " ");
  if (trimmed.length === 0 || trimmed.length > max) return null;
  return trimmed;
}

export async function handleWaitlist({ request, supabase }) {
  const params = new URL(request.url).searchParams;
  const action = params.get("action");

  if (action === "ping") {
    if (request.method !== "GET") return json({ error: "method_not_allowed" }, 405, { allow: "GET" });
    return json({ ok: true, service: "safeher-waitlist" });
  }

  if (action === "join") {
    if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405, { allow: "POST" });

    const type = request.headers.get("content-type") ?? "";
    if (!type.includes("application/json")) return json({ ok: false, error: "invalid_body" }, 400);

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ ok: false, error: "invalid_body" }, 400);
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return json({ ok: false, error: "invalid_body" }, 400);
    }

    const name = readText(body.name, 80);
    const emailRaw = readText(body.email, 254);
    let city = null;
    if (typeof body.city === "string" && body.city.trim() !== "") {
      city = readText(body.city, 80);
      if (!city) return json({ ok: false, error: "invalid_city" }, 400);
    }

    if (!name) return json({ ok: false, error: "invalid_name" }, 400);
    if (!emailRaw || !EMAIL.test(emailRaw)) return json({ ok: false, error: "invalid_email" }, 400);
    const email = emailRaw.toLowerCase();

    try {
      const { error } = await supabase.from("waitlist").insert({
        id: crypto.randomUUID(),
        name,
        email,
        city,
        created_at: new Date().toISOString(),
      });
      if (error) {
        // 23505 = unique violation on email: already signed up. Treat as success.
        if (String(error.code) === "23505") return json({ ok: true, joined: false });
        return json({ ok: false, error: "write_rejected" }, 503);
      }
      return json({ ok: true, joined: true });
    } catch {
      return json({ ok: false, error: "write_result_unknown" }, 503);
    }
  }

  return json({ error: "not_found" }, 404);
}
